#!/usr/bin/env python

import sys

# add adaptor based on designed primers
# for this format, the fwd_adaptor must be the F primer

usage = "usage: python add_adaptor.py inputfile\n"
usage = usage + "inputfile format is locus_name forward_primer_sequence reverse_primer_sequence"
if len(sys.argv)!= 2:
    print usage
    sys.exit(0)

infile = open(sys.argv[1],'r')
outname = sys.argv[1][0:-3] + 'adaptor.txt'
outfile = open(outname, 'w')

fwd_adaptor = "GCGTTATCGAGGTC"
rev_adaptor = "GTGCTCTTCCGATCT"

for line in infile:
    line = line.strip().split()
    f_primer = fwd_adaptor + line[1]
    r_primer = rev_adaptor + line[3]
    name = line[0][0:-1]
    f_name = line[0] + '_F'
    r_name = line[0] + '_R'
    mapInfo = line[5]
    ampLength = line[6]
    outline = '\t'.join([name, f_name, f_primer, r_name, r_primer, mapInfo, ampLength])
    outfile.write(outline+"\n")

infile.close()
outfile.close()

